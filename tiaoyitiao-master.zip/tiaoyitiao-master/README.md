# tiaoyitiao
仿写微信小游戏「跳一跳」，使用白鹭引擎
运行步骤
1.下载源码后使用wing打开
2.在EgretLauncher中设置该项目的发布为小游戏(填写一个项目名称)
3.在wing中执行egret run命令即可
